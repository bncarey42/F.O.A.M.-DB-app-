/*    */ package edu.saintpaul.csci2466.foam.roster;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RosterException
/*    */   extends Exception
/*    */ {
/*    */   public RosterException() {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public RosterException(String msg)
/*    */   {
/* 20 */     super(msg);
/*    */   }
/*    */   
/*    */   public RosterException(String message, Throwable cause) {
/* 24 */     super(message, cause);
/*    */   }
/*    */   
/*    */   public RosterException(Throwable cause) {
/* 28 */     super(cause);
/*    */   }
/*    */ }


/* Location:              /home/rfoy/Development/SPC/CSCI2466/HW2/lib/AAA000_LIB_FOAM.jar!/edu/saintpaul/csci2466/foam/roster/RosterException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */