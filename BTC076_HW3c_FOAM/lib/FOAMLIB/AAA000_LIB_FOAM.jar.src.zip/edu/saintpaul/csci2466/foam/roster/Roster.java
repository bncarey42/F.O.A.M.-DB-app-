/*     */ package edu.saintpaul.csci2466.foam.roster;
/*     */ 
/*     */ import edu.saintpaul.csci2466.foam.model.Athlete;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.TreeMap;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Roster
/*     */ {
/*     */   private static String filePath;
/*  31 */   private static Roster instance = null;
/*     */   private Map<String, Athlete> roster;
/*     */   
/*  34 */   static { Logger.getLogger(Roster.class.getName()).log(Level.INFO, "Roster, v2.13.3"); }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean initialize(String initFilePath)
/*     */   {
/*  46 */     boolean successful = false;
/*  47 */     if (filePath == null) {
/*  48 */       filePath = initFilePath;
/*  49 */       if (new File(initFilePath).exists()) {
/*  50 */         Logger.getLogger(Roster.class.getName()).log(Level.INFO, "Opening roster file ({0})", initFilePath);
/*  51 */         successful = true;
/*     */       } else {
/*     */         try {
/*  54 */           Logger.getLogger(Roster.class.getName()).log(Level.INFO, "Roster: creating new roster file ({0})", initFilePath);
/*  55 */           getInstance().clear();
/*  56 */           successful = new File(initFilePath).exists();
/*     */         } catch (RosterException ex) {
/*  58 */           Logger.getLogger(Roster.class.getName()).log(Level.SEVERE, null, ex);
/*     */         }
/*     */       }
/*     */     } else {
/*  62 */       Logger.getLogger(Roster.class.getName()).log(Level.WARNING, "Roster already initialized. Ignoring.");
/*     */     }
/*  64 */     return successful;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Roster getInstance()
/*     */     throws RosterException
/*     */   {
/*     */     
/*     */     
/*     */ 
/*  76 */     if (instance == null) {
/*  77 */       instance = new Roster();
/*     */     }
/*  79 */     return instance;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean isInitialized()
/*     */   {
/*  89 */     return filePath != null;
/*     */   }
/*     */   
/*     */   private static void checkIsInitialized() throws RosterException {
/*  93 */     if (filePath == null) {
/*  94 */       throw new RosterException("Roster not initialized");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Roster()
/*     */   {
/* 104 */     this.roster = new TreeMap();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized List<Athlete> findAll()
/*     */     throws RosterException
/*     */   {
/* 114 */     loadRoster();
/* 115 */     return new LinkedList(this.roster.values());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized boolean add(Athlete athlete)
/*     */     throws RosterException
/*     */   {
/* 126 */     loadRoster();
/*     */     
/* 128 */     boolean wasAdded = (!this.roster.containsKey(athlete.getNationalID())) && (this.roster.put(athlete.getNationalID(), athlete) == null);
/* 129 */     if (wasAdded) {
/* 130 */       saveRoster();
/*     */     }
/* 132 */     return wasAdded;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized boolean delete(String nationalID)
/*     */     throws RosterException
/*     */   {
/* 142 */     loadRoster();
/* 143 */     boolean wasDeleted = this.roster.remove(nationalID) != null;
/* 144 */     if (wasDeleted) {
/* 145 */       saveRoster();
/*     */     }
/* 147 */     return wasDeleted;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized boolean update(Athlete athlete)
/*     */     throws RosterException
/*     */   {
/* 158 */     return (delete(athlete.getNationalID())) && (add(athlete));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized Athlete find(String nationalID)
/*     */     throws RosterException
/*     */   {
/* 169 */     loadRoster();
/* 170 */     return (Athlete)this.roster.get(nationalID);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void clear()
/*     */     throws RosterException
/*     */   {
/* 179 */     this.roster.clear();
/* 180 */     saveRoster();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized boolean isOnRoster(String nationalId)
/*     */     throws RosterException
/*     */   {
/* 190 */     loadRoster();
/* 191 */     return this.roster.containsKey(nationalId);
/*     */   }
/*     */   
/*     */   private void loadRoster() throws RosterException {
/* 195 */     try { ObjectInputStream inFile = new ObjectInputStream(new FileInputStream(filePath));Throwable localThrowable3 = null;
/* 196 */       try { this.roster = ((Map)inFile.readObject());
/*     */       }
/*     */       catch (Throwable localThrowable1)
/*     */       {
/* 195 */         localThrowable3 = localThrowable1;throw localThrowable1;
/*     */       } finally {
/* 197 */         if (inFile != null) if (localThrowable3 != null) try { inFile.close(); } catch (Throwable localThrowable2) { localThrowable3.addSuppressed(localThrowable2); } else inFile.close();
/* 198 */       } } catch (Exception ex) { Logger.getLogger(Roster.class.getName()).log(Level.SEVERE, null, ex);
/* 199 */       throw new RosterException("Unable to load roster", ex);
/*     */     }
/*     */   }
/*     */   
/*     */   private void saveRoster() throws RosterException {
/* 204 */     try { ObjectOutputStream outFile = new ObjectOutputStream(new FileOutputStream(filePath));Throwable localThrowable3 = null;
/* 205 */       try { outFile.writeObject(this.roster);
/*     */       }
/*     */       catch (Throwable localThrowable1)
/*     */       {
/* 204 */         localThrowable3 = localThrowable1;throw localThrowable1;
/*     */       } finally {
/* 206 */         if (outFile != null) if (localThrowable3 != null) try { outFile.close(); } catch (Throwable localThrowable2) { localThrowable3.addSuppressed(localThrowable2); } else outFile.close();
/* 207 */       } } catch (IOException ex) { Logger.getLogger(Roster.class.getName()).log(Level.SEVERE, null, ex);
/* 208 */       throw new RosterException("Unable to save roster", ex);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/rfoy/Development/SPC/CSCI2466/HW2/lib/AAA000_LIB_FOAM.jar!/edu/saintpaul/csci2466/foam/roster/Roster.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */