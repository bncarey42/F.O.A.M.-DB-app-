/*    */ package edu.saintpaul.csci2466.foam.model;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.time.LocalDate;
/*    */ import java.time.Month;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract interface Athlete
/*    */   extends Serializable
/*    */ {
/*    */   public static final int INVALID_DATE = -1;
/* 27 */   public static final LocalDate OLYMPIC_DATE = LocalDate.of(2016, Month.AUGUST, 8);
/*    */   
/*    */   public abstract int getAge();
/*    */   
/*    */   public abstract LocalDate getDateOfBirth();
/*    */   
/*    */   public abstract String getFirstName();
/*    */   
/*    */   public abstract String getLastName();
/*    */   
/*    */   public abstract String getNationalID();
/*    */ }


/* Location:              /home/rfoy/Development/SPC/CSCI2466/HW2/lib/AAA000_LIB_FOAM.jar!/edu/saintpaul/csci2466/foam/model/Athlete.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */